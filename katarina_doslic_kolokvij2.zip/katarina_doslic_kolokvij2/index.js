var unesenoIme = prompt ("Unesite ime:")
alert ("Vaše ime je: " + unesenoIme)